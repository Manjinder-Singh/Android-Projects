/*
Copyright (c) 2011, Sony Ericsson Mobile Communications AB
Copyright (c) 2011-2013, Sony Mobile Communications AB

 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.

 * Neither the name of the Sony Ericsson Mobile Communications AB / Sony Mobile
 Communications AB nor the names of its contributors may be used to endorse or promote
 products derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.example.sonymobile.modelviewer;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import com.example.sonymobile.extension.GLRenderExtensionService;
import com.sonyericsson.extras.liveware.aef.control.Control;
import com.sonyericsson.extras.liveware.extension.util.control.ControlExtension;
import com.sonyericsson.extras.liveware.extension.util.control.ControlObjectClickEvent;
import com.sonyericsson.extras.liveware.extension.util.control.ControlView;
import com.sonyericsson.extras.liveware.extension.util.control.ControlView.OnClickListener;
import com.sonyericsson.extras.liveware.extension.util.control.ControlViewGroup;

/**
 * This is the SmartWatch 2 control extension for 3D Model Viewer. 
 * It provides extra control buttons for SmartEyeglass application.
 */
public class GLRenderControlSW2 extends ControlExtension {

    Bundle[] mMenuItemsText = new Bundle[3];
    private static final int MENU_ITEM_0 = 0;
    private static final int MENU_ITEM_1 = 1;
    private static final int MENU_ITEM_2 = 2;

    private ControlViewGroup mLayout = null;

    SharedPreferences prefs;
    
    public GLRenderControlSW2(Context context, final String hostAppPackageName) {
        super(context, hostAppPackageName);
        setupClickables(context);
        prefs = android.preference.PreferenceManager.getDefaultSharedPreferences(context);
        
        GLRenderExtensionService.mGLRenderControlSW2=this;

        initializeMenus();
        startViewer();
        

    }
  
    // Start extension on SmartEyeglasss
    public void startViewer()
    {
		// Set screen to stay awake
        setScreenState(Control.Intents.SCREEN_STATE_ON);
        
        if(GLRenderExtensionService.mGLRenderControlSEG == null)
        {
        	// Start SmartEyeglass extension
        	GLRenderExtensionService.Object.startSEGControl();
        }
        else
        {
        	// Resume SmartEyeglass extension
        	GLRenderExtensionService.mGLRenderControlSEG.requestStart();
        }
    }
    
    // Stop extension on SmartEyeglass
    public void stopViewer()
    {
        setScreenState(Control.Intents.SCREEN_STATE_AUTO);
        
        if(GLRenderExtensionService.mGLRenderControlSEG != null)
        {
        	GLRenderExtensionService.mGLRenderControlSEG.requestStop();
        } 
    }
    
    // Initialize menu items
    private void initializeMenus() {
        mMenuItemsText[0] = new Bundle();
        mMenuItemsText[0].putInt(Control.Intents.EXTRA_MENU_ITEM_ID, MENU_ITEM_0);
        mMenuItemsText[0].putString(Control.Intents.EXTRA_MENU_ITEM_TEXT, "Flip X");
        mMenuItemsText[1] = new Bundle();
        mMenuItemsText[1].putInt(Control.Intents.EXTRA_MENU_ITEM_ID, MENU_ITEM_1);
        mMenuItemsText[1].putString(Control.Intents.EXTRA_MENU_ITEM_TEXT, "Flip Y");
        mMenuItemsText[2] = new Bundle();
        mMenuItemsText[2].putInt(Control.Intents.EXTRA_MENU_ITEM_ID, MENU_ITEM_2);
        mMenuItemsText[2].putString(Control.Intents.EXTRA_MENU_ITEM_TEXT, "Flip Z");

    }
    
    // Toggle menu
    boolean mTextMenu=false;
    private void toggleMenu() {
        showMenu(mMenuItemsText);
        mTextMenu = !mTextMenu;
    }
    
    // Stop SmartEyeglass Control extension when SmartWatch2 extension is destroyed
    @Override
    public void onDestroy() {  
    	stopViewer();
    };

    // Start SmartEyeglass Control extension when SmartWatch2 extension is resuming
    @Override
    public void onResume() {
    	startViewer();
        Bundle[] data = null;

        showLayout(R.layout.remote_control, data);

    }

    // Stop SmartEyeglass Control extension when SmartWatch2 extension is paused
    @Override
    public void onPause() {
        stopViewer();  
    }

    // Pass UI clicks to Layout
    @Override
    public void onObjectClick(final ControlObjectClickEvent event) {
        if (event.getLayoutReference() != -1) {
            mLayout.onClick(event.getLayoutReference());
        }
    }

    // Check for menu button key
    @Override
    public void onKey(final int action, final int keyCode, final long timeStamp) {
    	if(keyCode == Control.KeyCodes.KEYCODE_OPTIONS && action == Control.Intents.KEY_ACTION_RELEASE)
    	{
    		toggleMenu();
    	} else {
    		super.onKey(action, keyCode, timeStamp);
    	}
    }    
    
    // Pass Swipe events to SmartEyeglass ControlExtension
    @Override
    public void onSwipe(final int direction)
    {
    	GLRenderExtensionService.mGLRenderControlSEG.onSwipe(direction);
    }
    
    // Handle menu items
    @Override
    public void onMenuItemSelected(final int menuItem) {
        switch(menuItem)
        {
        case MENU_ITEM_0:
        	GLRenderExtensionService.mGLRenderControlSEG.mModelRenderer.angleOffsetX+=180;
        break;
        case MENU_ITEM_1:
        	GLRenderExtensionService.mGLRenderControlSEG.mModelRenderer.angleOffsetY+=180;
        break;
        case MENU_ITEM_2:
        	GLRenderExtensionService.mGLRenderControlSEG.mModelRenderer.angleOffsetZ+=180;
        break;
        }
    }

    // Handle UI Buttons
    private void setupClickables(Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.remote_control, null);
        mLayout = (ControlViewGroup) parseLayout(layout);
        if (mLayout != null) {
            ControlView upperLeft = mLayout.findViewById(R.id.LeftBtn);
            upperLeft.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick() {
                	GLRenderExtensionService.mGLRenderControlSEG.zoomOut();
                }
            });
            ControlView upperRight = mLayout.findViewById(R.id.RightBtn);
            upperRight.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick() {
                	GLRenderExtensionService.mGLRenderControlSEG.zoomIn();
                }
            });
        }
    }

}
