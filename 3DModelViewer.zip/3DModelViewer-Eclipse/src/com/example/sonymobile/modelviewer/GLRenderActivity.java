/*
Copyright (c) 2011, Sony Mobile Communications Inc.
Copyright (c) 2014, Sony Corporation

 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.

 * Neither the name of the Sony Mobile Communications Inc.
 nor the names of its contributors may be used to endorse or promote
 products derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.example.sonymobile.modelviewer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import ar.com.daidalos.afiledialog.FileChooserDialog;
import ar.com.daidalos.afiledialog.FileChooserDialog.OnFileSelectedListener;


/**
 * This  is preferences activity for 3D Model Viewer application.
 */
public final class GLRenderActivity extends Activity {
	PreferenceHandler mPreferenceHandler;
	
	static GLRenderControlSW2 mGLRenderControlSW2;
	static GLRenderControlSEG mGLRenderControlSEG;
	
	FileChooserDialog dialog;
	String objFiles;
	public static String[] objs;
	ListView objList;
    ArrayList<String> listItems=new ArrayList<String>();
    CustomListItem adapter;	
    
	@Override
	protected void onStop() {
		super.onStop();
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPreferenceHandler = new PreferenceHandler(this); 

        dialog = new FileChooserDialog(this);
        
        // Help button shows compatibility instruction layout with HelpActivity
        Button btnHelp = (Button)this.findViewById(R.id.btnCompatibility);
        btnHelp.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				Intent myIntent = new Intent(GLRenderActivity.this, HelpActivity.class);
				startActivity(myIntent);  
			}
        	
        }); 
        
        // Add button shows file manager for adding obj files.
        Button addObj = (Button)this.findViewById(R.id.btnAdd);          
        addObj.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				dialog.show();	
			}
        	
        });      

        // Instantiate custom adapter
        adapter = new CustomListItem(listItems, this);

        // Assign custom adapter to listview
        ListView lView = (ListView)findViewById(R.id.listView1);
        lView.setAdapter(adapter);
        
        // Handle file selected events from File Chooser dialog
        dialog.addListener(new OnFileSelectedListener(){
			@Override
			public void onFileSelected(Dialog source, File file) {
				dialog.hide();
				if(!mPreferenceHandler.addObjFile(file.getAbsolutePath()))
				{
					errorDialog();
				}
				else
				{
					updateObjList();
				}
			}

			@Override
			public void onFileSelected(Dialog source, File folder, String name) {
						
			}       	
        });
        
        updateObjList();
    }
    
    // Show error for problematic .obj file.
    public void errorDialog()
    {
		AlertDialog.Builder alert = new AlertDialog.Builder(this);

		alert.setTitle("Error");
		alert.setMessage(getString(R.string.file_error));
		alert.show();
    }
    
    // Delete obj file on given index position and update list view.
    public void deleteObj(int index)
    {
    	mPreferenceHandler.deleteObjFile(index);
    	updateObjList();
    }
    
    // Update list view
    public void updateObjList()
    {
    	// Read selected Obj files from preferences
    	List<String> files = mPreferenceHandler.getObjFileNames();
    	listItems.clear();
        // Show select file dialog if no file has been selected
        if(files==null)
        {
        	dialog.show();
        }
        else
        {
	        // Show files in listview
        	listItems.addAll(files);
	    	adapter.notifyDataSetChanged();
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
