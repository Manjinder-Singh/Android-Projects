package com.example.sonymobile.modelviewer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PreferenceHandler {
	SharedPreferences mSharedPreferences;
	
	List<String> Files = new ArrayList<String>();
	
	public PreferenceHandler(Context context)
	{
		mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
		updateObjFiles();
	}
		
	private void updateObjFiles()
	{
		Files = new ArrayList<String>();
		String objFiles =  mSharedPreferences.getString("OBJFiles", "NOFILE");
        
        // Show select file dialog if no file has been selected
        if(objFiles.equals("NOFILE"))
        {
        	return;
        }
        else
        {
	        // Show files in listview
	    	String[] elements = objFiles.split(",");
	    	for(String element : elements)
	    	{
	    		if(element!="")
	    		{
	    			Files.add(element);
	    		}
	    	}
	    	
        }	
	}
	
	public List<String> getObjFilePaths()
	{
		return Files;
	}
	
	public List<String> getObjFileNames()
	{
		List<String> Temp = new ArrayList<String>();

    	for(String element : Files)
    	{
			String[] path = element.split("/");
			Temp.add(path[path.length-1]);
    	}

        return Files;
	}
	
	public boolean addObjFile(String FilePath)
	{
		// Check if the file is an obj file and has a jpg texture next to it with same name.
        File f = new File(FilePath.replace(".obj", ".jpg"));
        if (!FilePath.endsWith(".obj") || !f.exists()) 
        { 
        	return false; 
        }
        
		String objFiles =  mSharedPreferences.getString("OBJFiles", "NOFILE");
        
        if(objFiles.equals("NOFILE"))
        {
        	mSharedPreferences.edit().putString("OBJFiles", FilePath).commit();  
        }
        else
        {
        	mSharedPreferences.edit().putString("OBJFiles", objFiles +","+ FilePath).commit();  
        }
        updateObjFiles();
        return true;
	}
	
	public void deleteObjFile(int index)
	{
		// Get current files and clear saved files
		String objFiles =  mSharedPreferences.getString("OBJFiles", "NOFILE");        
		mSharedPreferences.edit().putString("OBJFiles", "NOFILE").commit(); 
        // Iterate through file names and add if index doesn't match with the index of current element
    	String[] elements = objFiles.split(",");
    	for(int i=0; i<elements.length; i++)
    	{
    		if(i!=index)
    		{
    			addObjFile(elements[i]);
    		}
    	}
    	updateObjFiles();		
	}
}
