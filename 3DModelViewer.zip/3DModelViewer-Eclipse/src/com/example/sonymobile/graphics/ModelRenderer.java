package com.example.sonymobile.graphics;
import java.io.File;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.opengl.GLUtils;

import com.example.sonymobile.modelviewer.GLRenderControlSEG;


public class ModelRenderer implements GLSurfaceView.Renderer {
	Context mContext;
    int w,h;
    private DrawModel model;
    
    public float Scale = 1.0f;
    public int angleOffsetX,angleOffsetY,angleOffsetZ;
    
    private int[] mTexture = new int[1];
    
    String mTextureFilePath;
    
    public ModelRenderer(Context context,String ModelFilePath, String TextureFilePath) {
    	mContext=context;
    	// Load 3d model file
        model = new DrawModel(mContext, ModelFilePath);
        mTextureFilePath=TextureFilePath;
        
    }
    private void loadTexture(GL10 gl) {
        try {
            File f = new File(mTextureFilePath);
            if (!f.exists()) { return; }
            Bitmap bitmap = BitmapFactory.decodeFile(mTextureFilePath);
            
            gl.glGenTextures(1, mTexture, 0);
            gl.glBindTexture(GL10.GL_TEXTURE_2D, mTexture[0]);
            GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bitmap, 0);
            bitmap.recycle();
        } catch (Exception e) {
            return;
        }
    }
    public void onDrawFrame(GL10 gl) {
        gl.glClearColor(0f, 0f, .7f, 1.0f);
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
        gl.glPushMatrix();

        // Apply rotation values from SmartEyeglass application
        gl.glRotatef(GLRenderControlSEG.orientationVector[1]+angleOffsetX,-1,0,0);
        gl.glRotatef(GLRenderControlSEG.orientationVector[0]+angleOffsetY,0,1,0);
        gl.glRotatef(GLRenderControlSEG.orientationVector[2]+angleOffsetZ,0,0,-1);

        // Scale the model
        gl.glScalef(Scale, Scale, Scale);
        
        // Draw the model
        model.draw(gl);
        gl.glPopMatrix();
    }

    public void onSurfaceChanged(GL10 gl, int width, int height) {
    	gl.glViewport(0, 0, width, height);
        w=width;
        h=height;
    }

    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        gl.glLoadIdentity();
        GLU.gluPerspective(gl, 25.0f, (256 * 1f) / 256, 1, 100);
        GLU.gluLookAt(gl, 0f, 0f, 12f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
        gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
        gl.glEnable(GL10.GL_DEPTH_TEST);
        gl.glEnable(GL10.GL_TEXTURE_2D);
        
        loadTexture(gl);

        gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_LINEAR);
        gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_LINEAR);
        gl.glTexEnvx(GL10.GL_TEXTURE_ENV, GL10.GL_TEXTURE_ENV_MODE, GL10.GL_MODULATE);
    }
}    